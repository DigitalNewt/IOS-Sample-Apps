//
//  FlickrAPIKey.h
//
//  Created for Stanford CS193p Winter 2013.
//  Copyright 2013 Stanford University
//  All rights reserved.
//
//  Get your own key!
//  No Flickr fetches will work without the API Key!
//

#define FlickrAPIKey @"86ab90e2a74d5fc8428b772f884213a6"
