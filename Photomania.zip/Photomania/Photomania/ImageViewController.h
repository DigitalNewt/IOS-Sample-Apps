//
//  ImageViewController.h
//  Shutterbug
//
//  Created by Newt on 2/24/13.
//  Copyright (c) 2013 Digital Newt LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController

@property (nonatomic, strong) NSURL *imageURL;

@end
