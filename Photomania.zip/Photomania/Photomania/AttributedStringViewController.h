//
//  AttributedStringViewController.h
//  Shutterbug
//
//  Created by Newt on 3/3/13.
//  Copyright (c) 2013 Digital Newt LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttributedStringViewController : UIViewController
@property (nonatomic, strong) NSAttributedString *text;
@end
