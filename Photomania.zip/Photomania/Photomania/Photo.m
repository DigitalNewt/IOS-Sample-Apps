//
//  Photo.m
//  Photomania
//
//  Created by Newt on 3/19/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import "Photo.h"
#import "Photographer.h"


@implementation Photo

@dynamic imageURL;
@dynamic subtitle;
@dynamic title;
@dynamic unique;
@dynamic latitude;
@dynamic longitude;
@dynamic thumbnailURLString;
@dynamic whoTook;

@end
