//
//  DemoPhotographerMapViewController.h
//  Photomania
//
//  Created by Newt on 3/19/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import "PhotographerMapViewController.h"

@interface DemoPhotographerMapViewController : PhotographerMapViewController

@end
