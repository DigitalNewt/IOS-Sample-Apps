//
//  CoolFaceTests.h
//  CoolFaceTests
//
//  Created by Newt on 4/29/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CoolFaceTests : SenTestCase

@end
