//
//  PhoneViewController.h
//  CoolFace
//
//  Created by Newt on 4/30/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface PhoneViewController : UIViewController<AVCaptureVideoDataOutputSampleBufferDelegate>
{
    BOOL isUsingFrontFacingCamera;
}
@end
