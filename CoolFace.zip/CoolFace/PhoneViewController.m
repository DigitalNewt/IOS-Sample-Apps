//
//  PhoneViewController.m
//  CoolFace
//
//  Created by Newt on 4/30/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import "PhoneViewController.h"

@interface PhoneViewController ()
@property (nonatomic,strong) AVCaptureSession * session;
@property (strong) AVCaptureDevice * videoDevice;
@property (strong) AVCaptureDeviceInput * videoInput;
@property (strong) AVCaptureVideoDataOutput * frameOutput;
@property (nonatomic, strong) IBOutlet UIImageView *imgView;
@property (nonatomic,strong) CIDetector * faceDetector;
@property (nonatomic,strong) CIContext * context;
@property (nonatomic,strong) UIImageView * glasses;
@end

@implementation PhoneViewController

-(CIContext*) context{
    if(!_context){
        _context = [CIContext contextWithOptions:nil];
    }
    return _context;
}

-(CIDetector*) faceDetector{
    if(!_faceDetector){
        NSDictionary *detectorOptions = [NSDictionary dictionaryWithObjectsAndKeys:CIDetectorAccuracyLow,CIDetectorAccuracy,nil];
        
        _faceDetector = [CIDetector detectorOfType:CIDetectorTypeFace
                                           context:nil options:detectorOptions];
    }
    return _faceDetector;
}

- (UIImage *) setImageOrientation:(CGImageRef)imageRef
{
    UIDeviceOrientation deviceOrientation=[UIDevice currentDevice].orientation;
    UIImage *image;
    
    if (deviceOrientation == UIDeviceOrientationLandscapeLeft) {
        image = [UIImage imageWithCGImage:imageRef scale:1.0 orientation:UIImageOrientationUp];
    }
    else if (deviceOrientation == UIDeviceOrientationLandscapeRight) {
        image = [UIImage imageWithCGImage:imageRef scale:1.0 orientation:UIImageOrientationDown];
    }
    else if (deviceOrientation == UIDeviceOrientationPortraitUpsideDown) {
        image = [UIImage imageWithCGImage:imageRef scale:1.0 orientation:UIImageOrientationLeft];  //TODO: fix orientation
    } else {
        image = [UIImage imageWithCGImage:imageRef scale:1.0 orientation:UIImageOrientationRight];
    }
    
    return image;
}


- (CIImage *) setHue:(CIImage *)ciImage
{
    // apply hue adjustment filter:
    CIFilter * filter = [CIFilter filterWithName:@"CIHueAdjust"];
    [filter setDefaults];
    [filter setValue:ciImage forKey:@"inputImage"];
    [filter setValue:[NSNumber numberWithFloat:2.0] forKey:@"inputAngle"];
    
    return [filter valueForKey:@"outputImage"];
}

- (void)setupAVCapture
{
    NSError *error = nil;
	
	AVCaptureSession *session = [AVCaptureSession new];
	if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
	    [session setSessionPreset:AVCaptureSessionPreset640x480];
	else
	    [session setSessionPreset:AVCaptureSessionPresetPhoto];
    
    // Select a video device, make an input
	AVCaptureDevice *videoDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
	AVCaptureDeviceInput *videoInput = [AVCaptureDeviceInput deviceInputWithDevice:videoDevice error:&error];
	require( error == nil, bail );
    {
        isUsingFrontFacingCamera = NO;
        if ( [session canAddInput:videoInput] )
            [session addInput:videoInput];
    }
    bail:
    {
//	[session release];
        if (error) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Failed with error %d", (int)[error code]]
                                                                message:[error localizedDescription]
                                                               delegate:nil
                                                      cancelButtonTitle:@"Dismiss"
                                                      otherButtonTitles:nil];
            [alertView show];
//		[alertView release];
//		[self teardownAVCapture];
        }
    }
}

-(void) captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection
{
    CVPixelBufferRef pb = CMSampleBufferGetImageBuffer(sampleBuffer);
    CIImage *ciImage = [CIImage imageWithCVPixelBuffer:pb];
    

    // pass detector the image:
    NSArray * features = [self.faceDetector featuresInImage:ciImage];
    
    bool faceFound = false;
    for(CIFaceFeature * face in features){
        if(face.hasLeftEyePosition && face.hasRightEyePosition){
            CGPoint eyeCenter = CGPointMake(face.leftEyePosition.x*0.5+face.rightEyePosition.x*0.5, face.leftEyePosition.y*0.5+face.rightEyePosition.y*0.5);
            
            // set the glasses position based on mouth position
            double scalex =self.imgView.bounds.size.height/ciImage.extent.size.width;
            double scaley =self.imgView.bounds.size.width/ciImage.extent.size.height;
            self.glasses.center = CGPointMake(scaley*eyeCenter.y-self.glasses.bounds.size.height/4.0,scalex*(eyeCenter.x));
            
            
            // set the angle of the glasses using eye deltas
            double deltax = face.leftEyePosition.x-face.rightEyePosition.x;
            double deltay = face.leftEyePosition.y-face.rightEyePosition.y;
            double angle = atan2(deltax, deltay);
            self.glasses.transform=CGAffineTransformMakeRotation(angle+M_PI);
            
            // set size based on distance between the two eyes:
            double scale = 3.0*sqrt(deltax*deltax+deltay*deltay);
            self.glasses.bounds = CGRectMake(0, 0, scale, scale);
            faceFound = true;
            
            break;
        }
        
    }
    
    if(faceFound){
        [self.glasses setHidden:NO];
    }else{
        [self.glasses setHidden:YES];
    }
    
    
    CGImageRef ref = [self.context createCGImage:[self setHue:ciImage] fromRect:ciImage.extent];
    self.imgView.image = [self setImageOrientation:ref];
    CGImageRelease(ref);
    
}



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	[self setupAVCapture];
//	square = [[UIImage imageNamed:@"squarePNG"] retain];
//	NSDictionary *detectorOptions = [[NSDictionary alloc] initWithObjectsAndKeys:CIDetectorAccuracyLow, CIDetectorAccuracy, nil];
//	faceDetector = [[CIDetector detectorOfType:CIDetectorTypeFace context:nil options:detectorOptions] retain];
//	[detectorOptions release];
    

    
//****** Old Code
	

//    self.videoDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
//    self.videoInput =[AVCaptureDeviceInput deviceInputWithDevice:self.videoDevice error:nil];
//    self.frameOutput = [[AVCaptureVideoDataOutput alloc] init];
//    self.frameOutput.videoSettings = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:kCVPixelFormatType_32BGRA] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
//    
//    [self.session addInput:self.videoInput];
//    [self.session addOutput:self.frameOutput];
//    
//    [self.frameOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
//    [self.session startRunning];
//    
//    self.glasses = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"glasses.png"]];
//    [self.glasses setHidden:YES];
//    [self.view addSubview:self.glasses];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
