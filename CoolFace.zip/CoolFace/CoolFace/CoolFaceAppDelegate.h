//
//  CoolFaceAppDelegate.h
//  CoolFace
//
//  Created by Brent Baker on 4/29/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoolFaceAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
