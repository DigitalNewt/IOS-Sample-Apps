//
//  main.m
//  CoolFace
//
//  Created by Newt on 4/29/13.
//  Copyright (c) 2013 Mobile Newt LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CoolFaceAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CoolFaceAppDelegate class]));
    }
}
